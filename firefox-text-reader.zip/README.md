# Read Selected Text Aloud - Source Code

This is the source code for the Firefox extension "Read Selected Text Aloud."

## Build Instructions

No build tools are required. This extension is written in plain HTML, JS, and JSON. To replicate:

1. Copy these files into a folder.
2. Zip the contents (not the folder itself).
3. Upload the `.zip` to the Firefox Add-ons Developer Hub.

## Requirements

- Firefox 58.0 or higher
- No Node.js or NPM used
